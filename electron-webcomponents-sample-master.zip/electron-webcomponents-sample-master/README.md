# electron-webcomponents-sample
Electron with Web Components Sample




### Install
```
npm install
```

### Run
```
npm start
```
